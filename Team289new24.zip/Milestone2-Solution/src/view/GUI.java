package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyListener;
import java.io.IOException;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import engine.Game;
import exceptions.InvalidTargetException;
import exceptions.MovementException;
import exceptions.NoAvailableResourcesException;
import exceptions.NotEnoughActionsException;
import model.characters.Character;
import model.characters.Direction;
import model.characters.Explorer;
import model.characters.Fighter;
import model.characters.Hero;
import model.characters.Medic;
import model.characters.Zombie;
import model.collectibles.Vaccine;
import model.world.CharacterCell;
import model.world.CollectibleCell;

public class GUI extends JFrame implements ActionListener  {
	private JPanel availableHeroesPanel;
	private JButton startGame;
	private JButton[] availableH;
	private Hero selectedHero;
	private JLabel backgroundLabel;
	private JPanel startPanel;
	private JPanel B1;
	private JButton attack;
	private JButton useSpecial;
	private JButton cure;
	private JButton endTurn;
	private JButton move;
	private JPanel B2;
	private JLabel showDetails;
	private Character Target;
	private JPanel detailsPanel;
	private JPanel guidePanel;
	private JLabel guideLabel;
	
	
	
	
	private JButton[][] mapButton = new JButton[15][15];
	private JComboBox<Direction> directions; 
	
	public GUI() {
		try {
			Game.loadHeroes("Heroes.csv");
		}catch(IOException e){
			JOptionPane.showMessageDialog(this,"There is NO Heroes Available!","ERROR",JOptionPane.ERROR_MESSAGE);
			return;
		}
		
		
		
		startGame = new JButton("START NEW GAME");
		startGame.addActionListener(this);
		
		showDetails = new JLabel();
		showDetails.setLayout(null);
		showDetails.setBounds(10,376,150,150);
		this.getContentPane().add(showDetails);
		
		guideLabel = new JLabel();
		guideLabel.setLayout(null);
		this.getContentPane().add(guideLabel);
		
		
		this.setTitle("Last of Us");
		this.setSize(500,500);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		startPanel = new JPanel();
		startPanel.setLayout(new BorderLayout());
		ImageIcon image = new ImageIcon("lastofUs1.png");
		ImageIcon backgroundImage = new ImageIcon("532407.jpg");
		backgroundLabel = new JLabel(backgroundImage);
		backgroundLabel.setLayout(new BorderLayout());
		backgroundLabel.add(startGame,BorderLayout.WEST);
		this.setIconImage(image.getImage());
		this.getContentPane().setBackground(new Color(123,50,250));
		startPanel.add(backgroundLabel);
		this.getContentPane().add(startPanel);
		this.setBounds(100,100,backgroundImage.getIconWidth(),backgroundImage.getIconHeight());
	    }
	    
	    
		
		
		
		
	
	public static void main (String[] args) {
		GUI g = new GUI();
	}
	
	public void showHeroSelection () {
		startGame.setVisible(false);
		backgroundLabel.remove(startGame);
		this.remove(startPanel);
		availableHeroesPanel = new JPanel();
		availableHeroesPanel.setLayout(new GridLayout(4,2));
		this.getContentPane().add(availableHeroesPanel,BorderLayout.CENTER);
		availableH = new JButton[Game.availableHeroes.size()];
		for(int i = 0; i<Game.availableHeroes.size();i++) {
			availableH[i] = new JButton();
			if(Game.availableHeroes.get(i).getName() == "Joel Miller")
				 availableH[i].setIcon(new ImageIcon("Joel_in_The_Last_of_Us.png"));
			if(Game.availableHeroes.get(i).getName() == "Ellie Williams")
				 availableH[i].setIcon(new ImageIcon("ellieWilliams.jfif"));
			if(Game.availableHeroes.get(i).getName() == "Tess")
				 availableH[i].setIcon(new ImageIcon("Tess.jpg"));
			if(Game.availableHeroes.get(i).getName() == "Riley Abel")
				 availableH[i].setIcon(new ImageIcon("RileyAbel.jfif"));
			if(Game.availableHeroes.get(i).getName() == "Tommy Miller")
				 availableH[i].setIcon(new ImageIcon("TommyMiller.jfif"));
			if(Game.availableHeroes.get(i).getName() == "Bill")
				 availableH[i].setIcon(new ImageIcon("Bill.jfif"));
			if(Game.availableHeroes.get(i).getName() == "David")
				 availableH[i].setIcon(new ImageIcon("David.webp"));
			if(Game.availableHeroes.get(i).getName() == "Henry Burell")
				 availableH[i].setIcon(new ImageIcon("Henry.jpg"));
			availableH[i].setText(Game.availableHeroes.get(i).getName());
			availableH[i].addActionListener(this);
			availableHeroesPanel.add(availableH[i]);
		}
	}
	
	public void removeHeroesButtons () {
		for(int i = 0; i<Game.availableHeroes.size();i++) {
			availableH[i].setVisible(false);
			this.remove(availableH[i]);
			this.remove(availableHeroesPanel);
		}
	}
		
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == startGame) {
		    showHeroSelection();
		    
		}
		for(int i = 0; i<Game.availableHeroes.size(); i++) {
    		if(e.getSource() == availableH[i]) {
    			JOptionPane.showMessageDialog(this,getHeroInfo(Game.availableHeroes.get(i)),"INFORMATION",JOptionPane.INFORMATION_MESSAGE);
    			selectedHero = Game.availableHeroes.get(i);
    			VisibilityFalse(selectedHero);
    			int result = JOptionPane.showConfirmDialog(this,"Are you sure you want this Character","Confirmation",JOptionPane.YES_NO_OPTION );
    			if(result == JOptionPane.YES_OPTION) {
    				this.setTitle(selectedHero.getName());
    				removeHeroesButtons();
    				startTheGame();
    				}
    			
    			else
    				VisibilityTrue();
    			
    			return;	
    	}
		}
		
		for(int k = 0; k<mapButton.length; k++) {
			for(int j = 0; j<mapButton.length; j++) {
				if(e.getSource() == mapButton[k][j]) {
					if(Game.map[k][j] instanceof CharacterCell && Game.map[k][j].isVisible()) {
						if(((CharacterCell)Game.map[k][j]).getCharacter() instanceof Hero) {
							selectedHero = (Hero) ((CharacterCell)Game.map[k][j]).getCharacter();
							showDetails.setText(getHeroInfo(selectedHero));
						}
						else {
							if(((CharacterCell)Game.map[k][j]).getCharacter() instanceof Zombie) {
								 Target =  (Zombie) ((CharacterCell)Game.map[k][j]).getCharacter();
								 showDetails.setText(getZombieData((Zombie)Target));
							}
						}
					}
				}
			}
		}
		if(e.getSource() == cure) {
			try {
				selectedHero.setTarget(Target);
				selectedHero.cure();
				showMap();
			}catch(InvalidTargetException |NotEnoughActionsException | NoAvailableResourcesException er) {
				JOptionPane.showMessageDialog(this, er.getMessage());
			}
		}
		if(e.getSource() == attack) {
			try {
				selectedHero.setTarget(Target);
				selectedHero.attack();
				winCase();
				lossCase();
				showMap();
			}catch (InvalidTargetException |NotEnoughActionsException er ) {
				JOptionPane.showMessageDialog(this, er.getMessage());
			}
		}
		
		
		
		
		
		if(e.getSource() == endTurn) {
			try {
				Game.endTurn();
				winCase();
				lossCase();
				showMap();
			}catch(InvalidTargetException | NotEnoughActionsException er) {
				JOptionPane.showMessageDialog(this, er.getMessage());
			}
		}
		if(e.getSource() == useSpecial) {
			try {
				selectedHero.setTarget(Target);
				selectedHero.useSpecial();
				showMap();
			}catch(InvalidTargetException |NoAvailableResourcesException er ) {
				JOptionPane.showMessageDialog(this, er.getMessage());
			}
		
		}
		if(e.getSource() == move) {
			Direction direction = (Direction) directions.getSelectedItem();
			try {
				selectedHero.move(direction);
				showMap();
			}catch (NotEnoughActionsException | MovementException er) {
				JOptionPane.showMessageDialog(this, er.getMessage());
			}
		}
		
		
		
		
	}
	
	public void startTheGame () {
		removeHeroesButtons();
		Game.startGame(selectedHero);
		availableHeroesPanel.setVisible(false);
		startGame.setVisible(false);
		this.getContentPane().setLayout(null);
		
		
		B1 =  new JPanel();
		B1.setLayout(new GridLayout(6,1));
		B1.setBounds(10,10,150,200);
		this.getContentPane().add(B1);
		attack = new JButton("ATTACK");
		attack.addActionListener(this);
		B1.add(attack);
		
		useSpecial = new JButton("Use SPECIAL Action");
		useSpecial.addActionListener(this);
		B1.add(useSpecial);
		
		cure = new JButton("CURE Zombie");
		cure.addActionListener(this);
		B1.add(cure);
		
		endTurn = new JButton("END turn");
		endTurn.addActionListener(this);
		B1.add(endTurn);
		
		move = new JButton("move");
		move.addActionListener(this);
		B1.add(move);
		
		Direction[] direction = {Direction.UP , Direction.DOWN , Direction.LEFT , Direction.RIGHT };
		directions = new JComboBox<Direction>(direction);
		directions.addActionListener(this);
		B1.add(directions);
		
		B2 =  new JPanel();
		B2.setPreferredSize(new Dimension(500,500));
		B2.setLayout(new GridLayout(15,15));
		B2.setBounds(200,10,600,600);
		this.getContentPane().add(B2);
		
		
		mapButton = new JButton[15][15];
		for(int i = 0; i<mapButton.length;i++) {
			for(int j =0 ; j<mapButton.length;j++) {
				mapButton[i][j] = new JButton();
				mapButton[i][j].addActionListener(this);
				B2.add(mapButton[i][j]);
			}
		}
		
		
		
		detailsPanel = new JPanel();
		detailsPanel.setBounds(10,376,150,150);
		this.getContentPane().add(detailsPanel);
		detailsPanel.add(showDetails);
		
		guidePanel = new JPanel();
		guidePanel.setBounds(850,376,150,150);
		this.getContentPane().add(guidePanel);
		guidePanel.add(guideLabel);
		guideLabel.setText(showGuide());
		
		
		
		showMap();
		
	}
	
	public void showMap () {
		for(int i = 0;i< mapButton.length;i++) {
			for(int j = 0;j< mapButton.length;j++) {
				mapButton[i][j].setIcon(null);
				mapButton[i][j].setText("");
				if(Game.map[i][j].isVisible() == false)
					mapButton[i][j].setBackground(new Color(192,192,192));
				else {
					if(Game.map[i][j] instanceof CharacterCell) {
						if(((CharacterCell)Game.map[i][j]).getCharacter() == null) {
							mapButton[i][j].setBackground(new Color(51,153,102));
						}
						else {
							if(((CharacterCell)Game.map[i][j]).getCharacter() instanceof Hero) {
								mapButton[i][j].setText(((CharacterCell)Game.map[i][j]).getCharacter().getName().charAt(0)+"");
							}
							else {
								if(((CharacterCell)Game.map[i][j]).getCharacter() instanceof Zombie) {
									mapButton[i][j].setIcon(new ImageIcon("zombie.jfif"));
								}
							}
						}
					
					}
					else {
						if(Game.map[i][j] instanceof CollectibleCell) {
							if(((CollectibleCell)Game.map[i][j]).getCollectible() instanceof Vaccine) {
								mapButton[i][j].setIcon(new ImageIcon("vaccine.png"));
							}
							else {
								mapButton[i][j].setIcon(new ImageIcon("supply.png"));
							}
						}
					}
				}
				
			}
		}
	}
	
	
	
	
	public void VisibilityFalse (Hero selectedHero) {
		for(int i = 0; i<Game.availableHeroes.size();i++) {
			if(Game.availableHeroes.get(i) != selectedHero) {
				availableH[i].setVisible(false);
			}
		}
	}
	public void VisibilityTrue () {
		for(int i = 0; i<Game.availableHeroes.size();i++) {
			availableH[i].setVisible(true);
		}
	}
	public String getHeroInfo(Hero h) {
		String type = "";
		if(h instanceof Fighter)
			type = "FIGHTER";
		if(h instanceof Medic)
			type = "Medic";
		if(h instanceof Explorer)
			type = "Explorer";
		return "<html><p>Type: " + type + "</p>" + "<p>Name: " + h.getName() + "</p>" + "<p>Health: " +h.getCurrentHp() + "</p>" + "<p>Attack DAMAGE: " + h.getAttackDmg() + "</p>" + "<p>Maximum Actions: " + h.getMaxActions() + "</p>" + "<p>nb of Supplies: " + h.getSupplyInventory().size() + "</p>" + "<p>nb of Vaccines: " + h.getVaccineInventory().size() +"</p><html>"; 
	}
	
	public String getZombieData(Zombie z){
		String s= "<html><p>Type : Zombie</p> "+ "<p>Name: " + z.getName() + "</p>"+ "<p>Health:"+ z.getCurrentHp()+ "</p>"+ "<p> Attack Damage:"+ z.getAttackDmg()+"</p></html>";
		return s;
	}
	
	public String showGuide() {
		return "<html><p> Up and down are inverted</p>" + "<p> Supply = black Cell</p>" + "<p> Vaccine = orange Cell</p><html>";
	}
	
	public void winCase () {
		if(Game.checkWin()==true) {
			JOptionPane.showMessageDialog(null,"CONGRATS, YOU WON!","Game Over",JOptionPane.INFORMATION_MESSAGE);
			System.exit(0);
		}
	}
	public void lossCase () {
		if(Game.checkGameOver() == true) {
			JOptionPane.showMessageDialog(null,"DEATH","Game Over",JOptionPane.INFORMATION_MESSAGE);
			System.exit(0);
		}
	}
	
	
	

}
